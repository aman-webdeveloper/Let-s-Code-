<script src="https://unpkg.com/aos@next/dist/aos.js"></script>

    AOS.init({
        once: false, // Optional: animation only once
    });

